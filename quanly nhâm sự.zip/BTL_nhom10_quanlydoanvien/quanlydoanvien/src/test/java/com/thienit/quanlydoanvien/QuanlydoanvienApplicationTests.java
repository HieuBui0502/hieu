package com.thienit.quanlydoanvien;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanlydoanvienApplicationTests {

	@Test
	void contextLoads() {
	}

}
