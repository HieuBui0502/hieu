package com.example.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CountServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String inputString = request.getParameter("inputString");
		int count = (inputString != null) ? inputString.length() : 0;

		// Store in request scope for JSP
		request.setAttribute("inputString", inputString);
		request.setAttribute("count", count);

		// Store in session for listener to track
		HttpSession session = request.getSession();
		session.setAttribute("inputString", inputString);

		// Forward to JSP
		request.getRequestDispatcher("/WEB-INF/count.jsp").forward(request, response);
	}
}